Responsibility for maintenance of this repository is split between the account, `CACM` team, and `Global Development` team based on following principles:

## Global Dev Team
is responsible for maintenance of following files
* `/event_wrapper.yml`
* `/blacklistevents_rules.yml`
* part of `/roles/requirements.yml` which reffers to following Ansible Roles
  *  src: git+https://github.ibm.com/Continuous-Engineering/ansible-role-event-final-ack.git
  *  src: git+https://github.ibm.com/Continuous-Engineering/ansible-role-event-pre-check.git
  *  src: git+https://github.ibm.com/Continuous-Engineering/ansible-role-event-socks-tunnel.git
  *  src: git+https://github.ibm.com/Continuous-Engineering/ansible-role-event-blacklisting.git

If this code is in under the Continuous-Engineering GitHub organization:

## CACM team is responsible for the rest of the content in this repository

If this code is in under any organization:

## The account team is responsible for the rest of the content in this repository

